package com.zeta.controller;

import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;



import com.zeta.service.Consumerservice;
import com.zeta.service.Consumerserviceimpl;



@RestController
public class MyController{
	@Autowired
	Consumerservice service;
	Consumerserviceimpl consume= new Consumerserviceimpl();
	

	@RequestMapping(value="/consumer", method=RequestMethod.GET)
	public Object getAllConsumer(){
		return consume.consumer();
		
	}
	
	
}
