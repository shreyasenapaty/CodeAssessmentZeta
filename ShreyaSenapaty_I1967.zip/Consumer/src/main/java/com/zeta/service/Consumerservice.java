package com.zeta.service;

import java.util.*;

import org.springframework.http.ResponseEntity;



public interface Consumerservice {
	public Object consumer();
}
