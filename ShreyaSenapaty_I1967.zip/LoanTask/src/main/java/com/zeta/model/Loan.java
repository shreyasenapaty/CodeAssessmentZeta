package com.zeta.model;

import java.sql.Date;

import javax.persistence.*;

@Entity
@Table(name="loan")
public class Loan {
	@Id
	private int loan_no;
	@Column
	private long adhaar_no;
	@Column
	private String full_name;
	@Column
	private String last_name;
	@Column
	private double loan_amt;
	@Column
	private Date start_date;
	@Column
	private int tenure;
	public int getLoan_no() {
		return loan_no;
	}
	public void setLoan_no(int loan_no) {
		this.loan_no = loan_no;
	}
	public long getAdhaar_no() {
		return adhaar_no;
	}
	public void setAdhaar_no(long adhaar_no) {
		this.adhaar_no = adhaar_no;
	}
	public String getFull_name() {
		return full_name;
	}
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public double getLoan_amt() {
		return loan_amt;
	}
	public void setLoan_amt(double loan_amt) {
		this.loan_amt = loan_amt;
	}
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	

}
