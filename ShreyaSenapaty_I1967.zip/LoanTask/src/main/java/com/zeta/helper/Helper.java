package com.zeta.helper;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Vector;

import org.apache.log4j.Logger;

public class Helper {
	static Logger lg=Logger.getLogger(Helper.class);
	public static void err(){
		lg.warn("Error");
	}
	public static void msg(String str){
		lg.info(str);
	}
	public static void num(int a){
		lg.info(a);
	}
	public static void obj(Object a){
		lg.info(a);
	}
	
}
