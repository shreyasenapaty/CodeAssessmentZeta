package com.zeta.service;

import java.util.*;

import com.zeta.model.Loan;

public interface Loanservice {
	public List<Loan> getLoans();
	public Loan getLoanByNo(int loanid);
	public Loan addNewLoan(Loan loan);
	public Loan updateLoan(Loan loan);
	public void deleteLoanByNo(int loanid);
	public void deleteAllLoans();
}
