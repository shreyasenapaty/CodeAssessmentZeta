package com.zeta.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zeta.dao.Loandaorepository;
import com.zeta.model.Loan;

@Service
public class Loanserviceimpl implements Loanservice {
	@Autowired
    Loandaorepository dao;

	public List<Loan> getLoans() {
		return dao.findAll();
	}


	public Loan getLoanByNo(int loanid) {
		return dao.findOne(loanid);
	}


	@Override
	public Loan addNewLoan(Loan loan) {
		return dao.save(loan);
	}


	public Loan updateLoan(Loan loan) {
		
		return dao.save(loan);
	}

	public void deleteLoanByNo(int loanid) {
		dao.delete(loanid);
		
	}


	public void deleteAllLoans() {
		dao.deleteAll();
		
	}
	

}
