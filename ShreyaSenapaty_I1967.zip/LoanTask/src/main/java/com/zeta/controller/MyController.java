package com.zeta.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zeta.helper.Helper;
import com.zeta.model.Loan;
import com.zeta.service.Loanservice;

@RestController
public class MyController {
	@Autowired
	Loanservice service;
	
	@RequestMapping(value="/loan/all",method=RequestMethod.GET)
	public List<Loan> getLoans(){
		return service.getLoans();
	}
	
	@RequestMapping(value= "/loan/{loan_no}", method= RequestMethod.GET)
	public Loan getLoanByNo(@PathVariable int loan_no) throws Exception {
		Helper.msg(this.getClass().getSimpleName() + " - Get loan details by id is invoked.");

		Loan loan =  service.getLoanByNo(loan_no);
	  
		return loan;
	}

	@RequestMapping(value= "/loan/add", method= RequestMethod.POST)
	public Loan createloan(@RequestBody Loan newloan) {
		Helper.msg(this.getClass().getSimpleName() + " - Create new loan method is invoked.");
		return service.addNewLoan(newloan);
	}

	@RequestMapping(value= "/loan/update/{id}", method= RequestMethod.PUT)
	public Loan updateLoan(@RequestBody Loan updemp, @PathVariable int id) throws Exception {
		System.out.println(this.getClass().getSimpleName() + " - Update loan details by id is invoked.");

		Loan loan =  service.getLoanByNo(id);
		

		// Required for the "where" clause in the sql query template.
		updemp.setLoan_no(id);
		return service.updateLoan(updemp);
	}


	@RequestMapping(value= "/loan/delete/{id}", method= RequestMethod.DELETE)
	public void deleteloanById(@PathVariable int id) throws Exception {
		Helper.msg(this.getClass().getSimpleName() + " - Delete loan by id is invoked.");

		Loan loan =  service.getLoanByNo(id);
		

		service.deleteLoanByNo(id);
	}

	@RequestMapping(value= "/loan/delete/all", method= RequestMethod.DELETE)
	public void deleteAll() {
		System.out.println(this.getClass().getSimpleName() + " - Delete all loans is invoked.");
		service.deleteAllLoans();
	}

}
