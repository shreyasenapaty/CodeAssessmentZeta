package com.zeta.service;

import java.io.IOException;
import java.util.Arrays;


import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import junit.framework.Assert;

public class Test3 {
	@Test
	public void loantest() throws IOException, HttpClientErrorException,ResourceAccessException {
		try {
			RestTemplate restTemplate= new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			// Set Content Type
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
			ResponseEntity<Object> response = restTemplate.exchange("http://localhost:8080/loan/delete/all", HttpMethod.DELETE, entity, Object.class);
			Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);
			Assert.assertNull(response.getBody());
		} catch (Exception e) {
			e.printStackTrace();
		}
		}

}
